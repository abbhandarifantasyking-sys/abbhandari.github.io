import { useState, useEffect, useCallback } from "react";

const TELEGRAM_LINK = "https://telegram.me/+hRpMv11-GCg1MjA1";
const REDIRECT_SECONDS = 5;

// Cricket ball SVG
function CricketBall({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none">
      <circle cx="50" cy="50" r="48" fill="#cc2200" stroke="#8B0000" strokeWidth="2" />
      <path d="M30 15 Q50 50 30 85" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M70 15 Q50 50 70 85" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" />
      <line x1="28" y1="20" x2="32" y2="22" stroke="#fff" strokeWidth="1.5" />
      <line x1="26" y1="30" x2="30" y2="31" stroke="#fff" strokeWidth="1.5" />
      <line x1="25" y1="40" x2="29" y2="40" stroke="#fff" strokeWidth="1.5" />
      <line x1="25" y1="50" x2="29" y2="50" stroke="#fff" strokeWidth="1.5" />
      <line x1="25" y1="60" x2="29" y2="60" stroke="#fff" strokeWidth="1.5" />
      <line x1="26" y1="70" x2="30" y2="69" stroke="#fff" strokeWidth="1.5" />
      <line x1="28" y1="80" x2="32" y2="78" stroke="#fff" strokeWidth="1.5" />
      <line x1="68" y1="22" x2="72" y2="20" stroke="#fff" strokeWidth="1.5" />
      <line x1="70" y1="31" x2="74" y2="30" stroke="#fff" strokeWidth="1.5" />
      <line x1="71" y1="40" x2="75" y2="40" stroke="#fff" strokeWidth="1.5" />
      <line x1="71" y1="50" x2="75" y2="50" stroke="#fff" strokeWidth="1.5" />
      <line x1="71" y1="60" x2="75" y2="60" stroke="#fff" strokeWidth="1.5" />
      <line x1="70" y1="69" x2="74" y2="70" stroke="#fff" strokeWidth="1.5" />
      <line x1="68" y1="78" x2="72" y2="80" stroke="#fff" strokeWidth="1.5" />
    </svg>
  );
}

// Telegram icon
function TelegramIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor">
      <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
    </svg>
  );
}

// Trophy icon
function TrophyIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor">
      <path d="M12 2C13.1 2 14 2.9 14 4H19C19 4 20 4 20 5V8C20 10 18 12 16 12C15.2 13.2 13.7 14 12 14C10.3 14 8.8 13.2 8 12C6 12 4 10 4 8V5C4 4 5 4 5 4H10C10 2.9 10.9 2 12 2ZM6 6V8C6 9.1 6.9 10 8 10V6H6ZM16 6V10C17.1 10 18 9.1 18 8V6H16ZM9 16H15V18H16C17.1 18 18 18.9 18 20V22H6V20C6 18.9 6.9 18 8 18H9V16Z" />
    </svg>
  );
}

// Stats card component
function StatCard({ icon, value, label, delay }: { icon: string; value: string; label: string; delay: string }) {
  const delayClass = delay === "1" ? "animate-slide-up-delay-2" : delay === "2" ? "animate-slide-up-delay-3" : "animate-slide-up-delay-4";
  return (
    <div className={`glass-card rounded-2xl p-4 sm:p-6 text-center ${delayClass} hover:scale-105 transition-transform duration-300`}>
      <div className="text-3xl sm:text-4xl mb-2">{icon}</div>
      <div className="text-2xl sm:text-3xl font-bold text-white mb-1">{value}</div>
      <div className="text-xs sm:text-sm text-blue-200">{label}</div>
    </div>
  );
}

// Feature card
function FeatureCard({ icon, title, desc, delay }: { icon: string; title: string; desc: string; delay: string }) {
  const delayClass = delay === "1" ? "animate-slide-up-delay-2" : delay === "2" ? "animate-slide-up-delay-3" : delay === "3" ? "animate-slide-up-delay-4" : "animate-slide-up-delay-5";
  return (
    <div className={`glass-card rounded-2xl p-5 sm:p-6 ${delayClass} hover:scale-105 hover:bg-white/15 transition-all duration-300 group`}>
      <div className="text-4xl sm:text-5xl mb-3 group-hover:scale-110 transition-transform duration-300">{icon}</div>
      <h3 className="text-lg sm:text-xl font-bold text-white mb-2">{title}</h3>
      <p className="text-sm text-blue-200 leading-relaxed">{desc}</p>
    </div>
  );
}

// Floating particles background
function FloatingParticles() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {[...Array(15)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full opacity-20"
          style={{
            width: `${Math.random() * 8 + 4}px`,
            height: `${Math.random() * 8 + 4}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: i % 3 === 0 ? '#FFD700' : i % 3 === 1 ? '#0088cc' : '#FF6B35',
            animation: `float ${3 + Math.random() * 4}s ease-in-out infinite ${Math.random() * 2}s`,
          }}
        />
      ))}
    </div>
  );
}

export function App() {
  const [countdown, setCountdown] = useState(REDIRECT_SECONDS);
  const [redirected, setRedirected] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleJoinClick = useCallback(() => {
    window.open(TELEGRAM_LINK, "_blank");
  }, []);

  useEffect(() => {
    // Show confetti after page loads
    const confettiTimer = setTimeout(() => setShowConfetti(true), 1500);

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          if (!redirected) {
            setRedirected(true);
            window.open(TELEGRAM_LINK, "_blank");
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(interval);
      clearTimeout(confettiTimer);
    };
  }, [redirected]);

  return (
    <div className="min-h-screen cricket-gradient text-white relative overflow-x-hidden">
      <FloatingParticles />

      {/* Confetti */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="absolute"
              style={{
                left: `${Math.random() * 100}%`,
                top: '-20px',
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`,
                background: ['#FFD700', '#FF6B35', '#0088cc', '#00ff88', '#ff4444', '#ff69b4'][i % 6],
                borderRadius: Math.random() > 0.5 ? '50%' : '2px',
                animation: `confetti-fall ${2 + Math.random() * 3}s linear ${Math.random() * 2}s forwards`,
              }}
            />
          ))}
        </div>
      )}

      {/* Background decorative elements */}
      <div className="absolute top-10 left-5 sm:left-10 opacity-10">
        <CricketBall className="w-20 h-20 sm:w-32 sm:h-32 animate-spin-slow" />
      </div>
      <div className="absolute top-40 right-5 sm:right-20 opacity-10">
        <CricketBall className="w-14 h-14 sm:w-20 sm:h-20 animate-spin-slow" />
      </div>
      <div className="absolute bottom-20 left-10 sm:left-20 opacity-10">
        <CricketBall className="w-16 h-16 sm:w-24 sm:h-24 animate-spin-slow" />
      </div>

      {/* Hero Section */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-10">
        {/* Top Badge */}
        <div className="animate-slide-down mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-full px-4 sm:px-6 py-2 sm:py-3">
            <span className="animate-wiggle inline-block">🏆</span>
            <span className="text-yellow-300 text-xs sm:text-sm font-semibold tracking-wide">#1 CRICKET TIPS CHANNEL</span>
            <span className="animate-wiggle inline-block">🏆</span>
          </div>
        </div>

        {/* Main Logo / Icon */}
        <div className="animate-bounce-in mb-6 sm:mb-8 relative">
          <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full telegram-gradient flex items-center justify-center animate-pulse-glow relative">
            <TelegramIcon className="w-14 h-14 sm:w-20 sm:h-20 text-white" />
            {/* Cricket ball orbiting */}
            <div className="absolute -top-2 -right-2 animate-float">
              <CricketBall className="w-10 h-10 sm:w-12 sm:h-12" />
            </div>
          </div>
        </div>

        {/* Main Heading */}
        <h1 className="animate-slide-up text-4xl sm:text-5xl md:text-7xl font-extrabold text-center leading-tight mb-4 sm:mb-6 max-w-4xl">
          <span className="gradient-text">Cricket Tips</span>
          <br />
          <span className="text-white">&</span>
          <br />
          <span className="gradient-text">Dream11 Teams</span>
        </h1>

        {/* Subtitle */}
        <p className="animate-slide-up-delay-1 text-base sm:text-xl md:text-2xl text-blue-200 text-center max-w-2xl mb-6 sm:mb-8 px-4 leading-relaxed">
          🏏 Get <span className="text-yellow-300 font-bold">expert cricket predictions</span>, winning Dream11 teams & match analysis delivered straight to your phone!
        </p>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3 sm:gap-6 w-full max-w-xl mb-8 sm:mb-10 px-2">
          <StatCard icon="👥" value="10K+" label="Members" delay="1" />
          <StatCard icon="🎯" value="90%" label="Accuracy" delay="2" />
          <StatCard icon="💰" value="FREE" label="To Join" delay="3" />
        </div>

        {/* CTA Button */}
        <div className="animate-slide-up-delay-4 w-full max-w-md px-4 mb-6">
          <button
            onClick={handleJoinClick}
            className="w-full group relative overflow-hidden telegram-gradient hover:brightness-110 text-white font-bold text-lg sm:text-xl py-4 sm:py-5 px-8 sm:px-10 rounded-2xl shadow-2xl shadow-blue-500/30 transition-all duration-300 hover:scale-105 hover:shadow-blue-500/50 active:scale-95 flex items-center justify-center gap-3"
          >
            <div className="absolute inset-0 animate-shimmer" />
            <TelegramIcon className="w-7 h-7 sm:w-8 sm:h-8 relative z-10 group-hover:rotate-12 transition-transform duration-300" />
            <span className="relative z-10">Join Telegram Channel</span>
            <span className="relative z-10 text-2xl">🚀</span>
          </button>
        </div>

        {/* Countdown / Auto-redirect notice */}
        <div className="animate-slide-up-delay-5 text-center">
          {countdown > 0 ? (
            <div className="flex flex-col items-center gap-3">
              <p className="text-blue-300 text-sm sm:text-base">
                ⏱️ Auto-redirecting to Telegram in <span className="text-yellow-300 font-bold text-lg sm:text-xl">{countdown}</span> seconds...
              </p>
              <div className="w-48 sm:w-64 h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full telegram-gradient rounded-full animate-progress" />
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <p className="text-green-400 text-sm sm:text-base font-semibold">✅ Redirected! Didn't open?</p>
              <button
                onClick={handleJoinClick}
                className="text-yellow-300 underline hover:text-yellow-200 text-sm sm:text-base font-semibold transition-colors"
              >
                Click here to join manually →
              </button>
            </div>
          )}
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 animate-float">
          <div className="flex flex-col items-center gap-2 text-blue-300/50">
            <span className="text-xs">Scroll down</span>
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold mb-4">
              Why <span className="gradient-text">Join Us?</span>
            </h2>
            <p className="text-blue-200 text-base sm:text-lg max-w-xl mx-auto">
              Everything you need to dominate Fantasy Cricket
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <FeatureCard
              icon="🏏"
              title="Match Predictions"
              desc="Expert analysis for every match with detailed insights on pitch, weather & team form."
              delay="1"
            />
            <FeatureCard
              icon="⭐"
              title="Dream11 Teams"
              desc="Ready-made winning teams with captain & vice-captain picks for maximum points."
              delay="2"
            />
            <FeatureCard
              icon="📊"
              title="Player Stats"
              desc="In-depth player statistics, recent form analysis & head-to-head records."
              delay="3"
            />
            <FeatureCard
              icon="🔔"
              title="Instant Updates"
              desc="Real-time toss updates, playing XI changes & last-minute team modifications."
              delay="4"
            />
          </div>
        </div>
      </section>

      {/* What You Get Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-4xl mx-auto">
          <div className="glass-card rounded-3xl p-6 sm:p-10 md:p-14">
            <div className="text-center mb-8 sm:mb-12">
              <TrophyIcon className="w-14 h-14 sm:w-16 sm:h-16 text-yellow-400 mx-auto mb-4 animate-float" />
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold mb-4">
                What You'll <span className="gradient-text">Get</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 mb-8 sm:mb-12">
              {[
                { emoji: "🏏", text: "IPL, T20 World Cup & all major tournament tips" },
                { emoji: "🎯", text: "90%+ accuracy rate on match predictions" },
                { emoji: "💎", text: "Grand League & Small League Dream11 teams" },
                { emoji: "📱", text: "Instant updates before every match" },
                { emoji: "🏆", text: "Captain & Vice-Captain recommendations" },
                { emoji: "📈", text: "Detailed pitch & weather reports" },
                { emoji: "🤝", text: "Active community of 10,000+ cricket fans" },
                { emoji: "🆓", text: "100% FREE - No hidden charges ever!" },
              ].map((item, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 sm:gap-4 bg-white/5 rounded-xl p-3 sm:p-4 hover:bg-white/10 transition-colors duration-300"
                >
                  <span className="text-2xl sm:text-3xl flex-shrink-0">{item.emoji}</span>
                  <span className="text-sm sm:text-base text-blue-100">{item.text}</span>
                </div>
              ))}
            </div>

            {/* Second CTA */}
            <div className="text-center">
              <button
                onClick={handleJoinClick}
                className="group relative overflow-hidden telegram-gradient hover:brightness-110 text-white font-bold text-lg sm:text-xl py-4 sm:py-5 px-8 sm:px-12 rounded-2xl shadow-2xl shadow-blue-500/30 transition-all duration-300 hover:scale-105 hover:shadow-blue-500/50 active:scale-95 inline-flex items-center gap-3"
              >
                <div className="absolute inset-0 animate-shimmer" />
                <TelegramIcon className="w-7 h-7 sm:w-8 sm:h-8 relative z-10 group-hover:rotate-12 transition-transform duration-300" />
                <span className="relative z-10">Join Now - It's FREE!</span>
                <span className="relative z-10 text-2xl">🎉</span>
              </button>
              <p className="text-blue-300/60 text-xs sm:text-sm mt-4">Join 10,000+ happy members today!</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials / Social Proof */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-center mb-10 sm:mb-14">
            Member <span className="gradient-text">Reviews</span> ⭐
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            {[
              {
                name: "Rohit S.",
                review: "Best Dream11 tips channel! Won ₹50,000 in just one week following their teams. 🔥",
                rating: "⭐⭐⭐⭐⭐",
                avatar: "🧑",
              },
              {
                name: "Vikas M.",
                review: "Accurate predictions every single match. The captain picks are always on point! 💯",
                rating: "⭐⭐⭐⭐⭐",
                avatar: "👨",
              },
              {
                name: "Priya K.",
                review: "Joined last month, already recovered all my Dream11 losses. Highly recommended! 🏆",
                rating: "⭐⭐⭐⭐⭐",
                avatar: "👩",
              },
            ].map((t, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-5 sm:p-6 hover:scale-105 transition-transform duration-300"
              >
                <div className="text-sm mb-2">{t.rating}</div>
                <p className="text-blue-100 text-sm sm:text-base mb-4 italic">"{t.review}"</p>
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{t.avatar}</span>
                  <span className="text-yellow-300 font-semibold text-sm">{t.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Supported Leagues */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold mb-10 sm:mb-14">
            Leagues We <span className="gradient-text">Cover</span> 🌍
          </h2>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
            {["🇮🇳 IPL", "🌏 T20 World Cup", "🏴 BBL", "🇵🇰 PSL", "🇬🇧 The Hundred", "🌍 ODI World Cup", "🇿🇦 SA20", "🏏 Asia Cup", "🇦🇺 AUS Series", "🏴 CPL"].map(
              (league, i) => (
                <div
                  key={i}
                  className="glass-card rounded-full px-5 sm:px-6 py-2.5 sm:py-3 text-sm sm:text-base font-medium hover:bg-white/15 transition-colors duration-300 hover:scale-105 cursor-default"
                >
                  {league}
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24 mb-8">
        <div className="max-w-3xl mx-auto text-center">
          <div className="animate-float mb-6">
            <span className="text-6xl sm:text-8xl">🏏</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold mb-4 sm:mb-6">
            Don't Miss <span className="gradient-text">Another Win!</span>
          </h2>
          <p className="text-blue-200 text-base sm:text-xl mb-8 sm:mb-10 max-w-xl mx-auto">
            Join our Telegram channel now and start winning with expert cricket tips & Dream11 teams!
          </p>

          <button
            onClick={handleJoinClick}
            className="group relative overflow-hidden bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 hover:brightness-110 text-white font-bold text-xl sm:text-2xl py-5 sm:py-6 px-10 sm:px-14 rounded-2xl shadow-2xl shadow-orange-500/30 transition-all duration-300 hover:scale-105 hover:shadow-orange-500/50 active:scale-95 inline-flex items-center gap-3 sm:gap-4 animate-pulse-glow"
          >
            <div className="absolute inset-0 animate-shimmer" />
            <TelegramIcon className="w-8 h-8 sm:w-10 sm:h-10 relative z-10 group-hover:rotate-12 transition-transform duration-300" />
            <span className="relative z-10">JOIN NOW FREE</span>
            <span className="relative z-10 text-3xl">🏆</span>
          </button>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-blue-300/60 text-xs sm:text-sm">
            <span>✅ 100% Free</span>
            <span>✅ No Spam</span>
            <span>✅ Expert Tips</span>
            <span>✅ Daily Updates</span>
          </div>
        </div>
      </section>

      {/* Sticky bottom bar for mobile */}
      <div className="fixed bottom-0 left-0 right-0 z-50 p-3 sm:p-4 bg-gradient-to-t from-[#1a1a2e] via-[#1a1a2e]/95 to-transparent md:hidden">
        <button
          onClick={handleJoinClick}
          className="w-full group relative overflow-hidden telegram-gradient text-white font-bold text-base sm:text-lg py-3.5 sm:py-4 px-6 rounded-xl shadow-2xl shadow-blue-500/30 flex items-center justify-center gap-2 active:scale-95 transition-transform duration-200"
        >
          <div className="absolute inset-0 animate-shimmer" />
          <TelegramIcon className="w-6 h-6 relative z-10" />
          <span className="relative z-10">Join Telegram Channel</span>
          <span className="relative z-10">🏏</span>
        </button>
      </div>

      {/* Footer */}
      <footer className="relative z-10 text-center py-8 sm:py-10 px-4 border-t border-white/5 mb-16 md:mb-0">
        <div className="flex items-center justify-center gap-2 mb-3">
          <CricketBall className="w-5 h-5" />
          <span className="text-blue-300/60 text-xs sm:text-sm">Cricket Tips & Dream11 Teams</span>
          <CricketBall className="w-5 h-5" />
        </div>
        <p className="text-blue-300/40 text-xs">
          © {new Date().getFullYear()} All rights reserved. Join our Telegram for the best cricket experience!
        </p>
      </footer>
    </div>
  );
}
